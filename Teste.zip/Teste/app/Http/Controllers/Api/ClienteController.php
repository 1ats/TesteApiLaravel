<?php

namespace App\Http\Controllers\Api;

use App\Http\Requests\ClienteRequest;
use App\Http\Resources\ClienteCollection;
use App\Http\Resources\ClienteResource;
use App\Api\ApiMessages;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Cliente;

class ClienteController extends Controller
{
    private $cliente;

 public function __construct(Cliente $cliente){

 	$this->cliente = $cliente; 
 }

     public function index(Request $request)
    {
    	$cliente = $this->cliente->paginate(5);
        return response()->json($cliente,200);
      //return new ClienteCollection($cliente);
    	
    }

	public function show($id)
	{
		
	   // return new ClienteResource($cliente);

		try {
			
			$cliente = $this->cliente->findOrFail($id);

			return response()->json($cliente,200);

		} catch (\Exception $e) {
			
			//$message = new ApiMessages($e->getMessage());
		    return response()->json(['erro'=> $e->getMessage()],401);

		}
	}

    public function save(ClienteRequest $request)
    {
    	$data = $request->all();

    	try {
			
			$cliente = $this->cliente->create($data);
			
			return response()->json(['data' => ['msg' => 'Cliente cadastrado com sucesso!']],200);

		} catch (Exception $e) {
			
			return response()->json(['erro'=> $e->getMessage()],401);

		}
	}

    public function update(Request $request)
    {
    	$data = $request->all();

    		try {
			
			$cliente = $this->cliente->findOrFail($data['id']);

			$cliente->update($data);

			return response()->json(['data' => ['msg' => 'Cliente atualizado com sucesso!']],200);

		} catch (Exception $e) {
			
			return response()->json(['erro'=> $e->getMessage()],401);

		}
    }

    public function delete($id)
    {

		try {
			
			$cliente = $this->cliente->findOrFail($id);

    	    $cliente->delete();

            return response()->json(['data' => ['msg' => 'Cliente removido com sucesso!']],200);

		} catch (Exception $e) {
			
			return response()->json(['erro'=> $e->getMessage()],401);

		} 

    }
}
