<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Iten;

class ItemController extends Controller
{
    private $item;

   public function __construct(Iten $item){

   	$this->item = $item;

   }

 public function show($cliente_id)
	{

		try {
			
			$itens = \App\Iten::where("cliente_id",$cliente_id)->get();

			return response()->json($itens,200);

		} catch (Exception $e) {
			
			return response()->json(['erro'=> $e->getMessage()],401);

		}
	}

    public function save(Request $request)
    {
    	$data = $request->all();

    	try {
			
			$item = $this->item->create($data);
			
			return response()->json(['data' => ['msg' => 'Item cadastrado com sucesso!']],200);

		} catch (Exception $e) {
			
			return response()->json(['erro'=> $e->getMessage()],401);

		}
	}
}
