<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Cliente extends Model
{
    
    protected $fillable = [
		'nome', 'Documento', 'UF', 'Municipio' , 'CEP' , 'Rua', 'Complemento'
    ];

public function itens()
    {
    	return $this->hasMany(Iten::class);
    }
}
