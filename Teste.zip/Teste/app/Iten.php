<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Iten extends Model
{
      protected $fillable = [
		'nome', 'preco', 'codigo', 'cliente_id'
    ];

 public function cliente()
    {
    	return $this->belongsTo(Cliente::class);
    }
}
